﻿using System;
using System.IO;

namespace Proj4
{
    class TwoDimMass
    {
        int[,] mass;
        public TwoDimMass(int n1, int n2, int min, int max)
        {
            mass = new int[n1, n2];
            Random random = new Random();
            for (int i = 0; i < n1; i++)
                for (int j = 0; j < n2; j++)
                    mass[i, j] = random.Next(min, max);
        }
        public TwoDimMass(int n, int min, int max)
        {
            mass = new int[n, n];
            Random random = new Random();
            for (int i = 0; i < n; i++)
                for (int j = 0; j < n; j++)
                    mass[i, j] = random.Next(min, max);
        }
        public TwoDimMass(string filename)
        {
            using (StreamReader sr = new StreamReader(filename))
            {
                int n1 = int.Parse(sr.ReadLine());
                int n2 = int.Parse(sr.ReadLine());
                mass = new int[n1,n2];
                for (int i = 0; i < mass.GetLength(0); i++)
                {
                    string[] str = sr.ReadLine().Split(' ');
                    for (int j = 0; j < mass.GetLength(1); j++)
                        mass[i, j] = int.Parse(str[j]);
                }
                    
            }
        }
        public void Write(string filename)
        {
            using (StreamWriter sw = new StreamWriter(filename, false))
            {
                for (int i = 0; i < mass.GetLength(0); i++)
                {
                    for (int j = 0; j < mass.GetLength(1); j++)
                        sw.Write(mass[i, j] + "\t") ;
                    sw.WriteLine();
                }
            }
        }
        public void GetNumMax(out int num)
        {
            num = 0;
            int max = Max;
            for (int i = 0; i < mass.GetLength(0); i++)
                for (int j = 0; j < mass.GetLength(1); j++)
                    if (mass[i, j] == max)
                        num = mass.GetLength(0) * i + j + 1;  // из нескольких максимальных выведет последнее
        }
        public int GetSum()
        {
            int sum = 0;
            for (int i = 0; i < mass.GetLength(0); i++)
                for (int j = 0; j < mass.GetLength(1); j++)
                    sum += mass[i,j];
            return sum;
        }
        public int Min
        {
            get
            {
                int min = mass[0, 0];
                for (int i = 0; i < mass.GetLength(0); i++)
                    for (int j = 0; j < mass.GetLength(1); j++)
                        if (mass[i, j] < min)
                            min = mass[i, j];
                return min;
            }
        }
        public int Max
        {
            get
            {
                int max = mass[0, 0];
                for (int i = 0; i < mass.GetLength(0); i++)
                    for (int j = 0; j < mass.GetLength(1); j++)
                        if (mass[i, j] > max)
                            max = mass[i, j];
                return max;
            }
        }
        public override string ToString()
        {
            string s = "";
            for (int i = 0; i < mass.GetLength(0); i++)
            {
                for (int j = 0; j < mass.GetLength(1); j++)
                    s += mass[i, j] + "\t";
                s += "\n";
            }
            return s;
        }

    }
}
