﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Proj4
{
    /*Задание: 4. *а) Реализовать класс для работы с двумерным массивом. Реализовать конструктор, заполняющий массив случайными числами.
                  Создать методы, которые возвращают сумму всех элементов массива, сумму всех элементов массива больше заданного, свойство,
                  возвращающее минимальный элемент массива, свойство, возвращающее максимальный элемент массива, метод, возвращающий номер 
                  максимального элемента массива (через параметры, используя модификатор ref или out)
                  *б) Добавить конструктор и методы, которые загружают данные из файла и записывают данные в файл.
                  Дополнительные задачи
                  в) Обработать возможные исключительные ситуации при работе с файлами.
     Фамилия: Орлов
*/
    class Program
    {
        static void Main(string[] args)
        {
            Console.Title = "Двумерные массивы";
            // не совсем понял, что требуется в задании вывода суммы всех элементов массива больше заданного, но не стал отвлекать этим вопросим.
            try
            {
                TwoDimMass twoDimMass1 = new TwoDimMass(3, -5, 5);
                TwoDimMass twoDimMass2 = new TwoDimMass(AppDomain.CurrentDomain.BaseDirectory + "file.txt");
                Console.WriteLine(twoDimMass1);
                Console.WriteLine($"Сумма:\t{twoDimMass1.GetSum()}");
                Console.WriteLine($"Мax:\t{twoDimMass1.Max}");
                Console.WriteLine($"Min:\t{twoDimMass1.Min}");
                twoDimMass1.GetNumMax(out int num);
                Console.WriteLine($"№ Max:\t{num}");
                twoDimMass1.Write(AppDomain.CurrentDomain.BaseDirectory + "file1.txt");

                Console.WriteLine(twoDimMass2);

                Console.ReadKey(true);
            }
            catch(SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
    }
}
