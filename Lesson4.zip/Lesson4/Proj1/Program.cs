﻿using System;

namespace Proj1
{
    /*Задание: 1. Дан целочисленный массив из 20 элементов. Элементы массива могут принимать целые значения от –10 000 до 10 000 включительно.
               Написать программу, позволяющую найти и вывести количество пар элементов массива, в которых хотя бы одно число делится на 3.
     Фамилия: Орлов
    */
    class Program
    {
        static void Main(string[] args)
        {
            Console.Title = "Массивы";

            int count = 0;
            int[] mass = new int[20];
            Random random = new Random();
            for(int i = 0; i < mass.Length; i++)
                mass[i] = random.Next(-10000, 10000);
            for(int i = 0; i < mass.Length; i++)
            {
                if (i != mass.Length - 1)
                    if (mass[i] % 3 == 0 || mass[i + 1] % 3 == 0)
                        count++;
                Console.Write($"{mass[i]} ");
            }
            Console.WriteLine();
            Console.WriteLine(count);
            Console.ReadKey(true);
        }
    }
}
