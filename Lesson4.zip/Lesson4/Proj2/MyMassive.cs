﻿using System;
using System.IO;

namespace Proj2
{
    class MyMassive
    {
        int[] mass;
        public MyMassive(int n, int value)
        {
            mass = new int[n];
            for (int i = 0; i < mass.Length; i++)
                mass[i] = value;
        }
        public MyMassive(int n, int start, int step)
        {
            mass = new int[n];
            mass[0] = start;
            for (int i = 1; i < mass.Length; i++)
                mass[i] = mass[i - 1] + step;
        }
        public MyMassive(string filename)
        {
            using(StreamReader sr = new StreamReader(filename))
            {
                int N = int.Parse(sr.ReadLine());
                mass = new int[N];
                for (int i = 0; i < N; i++)
                    mass[i] = int.Parse(sr.ReadLine());
            }
        }
        public void Write(string filename)
        {
            using (StreamWriter sw = new StreamWriter(filename,false))
            {
                for (int i = 0; i < mass.Length; i++)
                    sw.WriteLine(mass[i]);
            }
        }
        public int CountMax()
        {
            int count = 0;
            int max = Max;
            for (int i = 0; i < mass.Length; i++)
                if (mass[i] == max)
                    count++;
            return count;
        }
        public void Multi(int count)
        {
            for (int i = 0; i < mass.Length; i++)
                mass[i] *= count;
        }
        public void Inverse()
        {
            for (int i = 0; i < mass.Length; i++)
            {
                if (mass[i] > 0)
                    mass[i] = mass[i] - mass[i] - mass[i]; // не стал *2, подумал для чисел за пределами int не подойдёт 
                else
                    mass[i] = mass[i] + Math.Abs(mass[i]) + Math.Abs(mass[i]);
            }
        }
        public int GetSum()
        {
            int sum = 0;
            for(int i = 0; i < mass.Length; i++)
                sum += mass[i];
            return sum;
        }
        public int Max
        {
            get
            {
                int max = mass[0];
                for (int i = 1; i < mass.Length; i++)
                    if (mass[i] > max) max = mass[i];
                return max;
            }
        }
        public int Min
        {
            get
            {
                int min = mass[0];
                for (int i = 1; i < mass.Length; i++)
                    if (mass[i] < min) min = mass[i];
                return min;
            }
        }
        public override string ToString()
        {
            string result = "";
            foreach (int i in mass)
                result = result + i + " ";
            return result;
        }

    }
}
