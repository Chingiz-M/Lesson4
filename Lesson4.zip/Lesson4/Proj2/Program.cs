﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Proj2
{
    /*Задание: 2. а) Дописать класс для работы с одномерным массивом.Реализовать конструктор, создающий массив заданной размерности
                  и заполняющий массив числами от начального значения с заданным шагом. Создать свойство Sum, которые возвращают сумму 
                  элементов  массива, метод Inverse, меняющий знаки у всех элементов массива, метод Multi, умножающий каждый элемент
                  массива на определенное число, свойство MaxCount, возвращающее количество максимальных элементов.
                  В Main продемонстрировать работу класса.
                  б)Добавить конструктор и методы, которые загружают данные из файла и записывают данные в файл.
    Фамилия: Орлов
*/
    class Program
    {
        static void Main(string[] args)
        {
            Console.Title = "Массивы";

            MyMassive massive1 = new MyMassive(5, -3, 2);
            MyMassive massive2 = new MyMassive(AppDomain.CurrentDomain.BaseDirectory + "file.txt");

            Console.WriteLine($"Массив1:\t{massive1}");
            Console.WriteLine($"Сумма:\t\t{massive1.GetSum()}");
            massive1.Inverse();
            Console.WriteLine($"Инверсия:\t{massive1}");
            massive1.Multi(3);
            Console.WriteLine($"Умножение:\t{massive1}");
            massive1.Write(AppDomain.CurrentDomain.BaseDirectory + "file1.txt");
            Console.WriteLine();
            Console.WriteLine($"Массив2:\t{massive2}");
            Console.WriteLine($"MaxCount:\t{massive2.CountMax()}");

            Console.ReadKey(true);
        }
    }
}
