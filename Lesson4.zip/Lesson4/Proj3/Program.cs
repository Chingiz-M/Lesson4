﻿using System;


namespace Proj3
{
    /*Задание: 3. Решить задачу с логинами из предыдущего урока, только логины и пароли считать из файла в массив.
                Создайте структуру Account, содержащую Login и Password.
     Фамилия: Орлов
*/
    class Program
    {
        static void Main(string[] args)
        {
            Console.Title = "Авторизация";
            Authorization(AppDomain.CurrentDomain.BaseDirectory + "Auth.txt");
        }
        static public void Authorization(string filename)
        {
            int attempt = 3;
            Account account = new Account(filename);
            string login = account.Login;
            string password = account.Password;

            do
            {
                Console.Clear();
                Console.Write("Введите пароль: ");
                string temppassw = Console.ReadLine();
                Console.Write("Введите логин: ");
                string templogin = Console.ReadLine();

                if (templogin != login || temppassw != password)
                {
                    Console.WriteLine($"Вы ввели неверные данные\nУ вас осталось {--attempt} попыток(Для продолжения нажмите любую кнопку)");
                    Console.ReadKey(true);
                }
                else
                {
                    Console.WriteLine($"Вы ввели верные данные!");
                    Console.ReadKey(true);
                    break;
                }
            }
            while (attempt > 0);
            
        }
    }
}
