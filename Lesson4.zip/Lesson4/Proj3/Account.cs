﻿using System;
using System.IO;

namespace Proj3
{
    struct Account
    {
        public Account(string filename)
        {
            using (StreamReader sr = new StreamReader(filename))
            {
                Login = sr.ReadLine();
                Password = sr.ReadLine();
            }
        }
        public string Login { get; set; }
        public string Password { get; set; }
    }
}
